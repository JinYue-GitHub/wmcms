<?php
/**
* 插件前台方法
*
* @version        $Id: wmcms.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
class WMCMSPlugin extends Plugin
{
	private $table = '@plugin_demo';
	function __construct()
	{
	}
	
	//pc首页方法
	public function Action_index()
	{
	}

	//移动方法
	public function Action_index_m()
	{
	}
}
?>