<?php
/**
* 插件后台管理
*
* @version        $Id: admin.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
class WMCMSPluginAdmin extends Plugin
{
	private $table = '@plugin_demo';
	function __construct()
	{
	}
	
	//基本参数设置
	public function Action_config()
	{
	}
}
?>