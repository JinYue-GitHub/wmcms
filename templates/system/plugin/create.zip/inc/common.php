<?php
/**
* 公共事件处理文件
* @version        $Id: config.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
?>