<?php
/**
* 插件配置文件
* @name 		     命名方法：plugin.模块文件夹名.参数域名
* @version        $Id: config.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
?>