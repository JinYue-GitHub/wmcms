<?php
/**
* 公共方法文件
* @name 		     方法命名采用驼峰 plugin+插件名+方法名
* @version        $Id: function.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
?>