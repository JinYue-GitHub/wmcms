<?php
/**
* 插件的后台管理目录文件
* @version        $Id: menu.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
$pluginMenu = array(
	'system'=>array(
		'name'=>'系统菜单',
		'menu'=>array(
			array('name'=>'参数配置','action'=>'config'),
		),
	),
);
?>