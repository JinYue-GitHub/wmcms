<?php
/**
* 卸载插件的时候执行的sql
*
* @version        $Id: uninstall.php 2019年10月27日 12:31  weimeng
* @package        WMCMS
* @copyright      Copyright (c) 2015 WeiMengCMS, Inc.
* @link           http://www.weimengcms.com
*
*/
?>